package com.mycompany.datospersonales; // Asegúrate de que esto coincida con tu paquete

public class Main {
    public static void main(String[] args) {
        // Crear un arreglo multidimensional para almacenar datos de compañeros
        String[][] datosCompaneros = new String[5][4]; // 5 registros, 4 campos cada uno

        // Llenar los datos
        datosCompaneros[0] = new String[]{"Daniel", "Medina", "Electrónica", "TEST"};
        datosCompaneros[1] = new String[]{"Monica", "Jiz", "Computación", "IMSA"};
        datosCompaneros[2] = new String[]{"José", "González", "Ingeniería", "XYZ"};
        datosCompaneros[3] = new String[]{"Ana", "Pérez", "Arquitectura", "ABC"};
        datosCompaneros[4] = new String[]{"Luis", "Martínez", "Biología", "DEF"};

        // Imprimir los datos
        System.out.println("Datos de mis compañeros de clase:");
        System.out.printf("%-10s %-10s %-15s %-10s%n", "Nombre", "Apellido", "Carrera", "Lugar Trabajo");
        for (String[] registro : datosCompaneros) {
            System.out.printf("%-10s %-10s %-15s %-10s%n", registro[0], registro[1], registro[2], registro[3]);
        }
    }
}
